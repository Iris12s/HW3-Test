package databasePart1;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import application.Answer;
import application.Clarification;
import application.Question;
import application.User;
import javafx.collections.ObservableList;


/**
 * The DatabaseHelper class is responsible for managing the connection to the database,
 * performing operations such as user registration, login validation, and handling invitation codes.
 */
public class DatabaseHelper {

	// JDBC driver name and database URL 
	static final String JDBC_DRIVER = "org.h2.Driver";   
	static final String DB_URL = "jdbc:h2:~/FoundationDatabase";  

	//  Database credentials 
	static final String USER = "sa"; 
	static final String PASS = ""; 

	private Connection connection = null;
	private Statement statement = null; 
	//	PreparedStatement pstmt

	public void connectToDatabase() throws SQLException {
		try {
			Class.forName(JDBC_DRIVER); // Load the JDBC driver
			System.out.println("Connecting to database...");
			connection = DriverManager.getConnection(DB_URL, USER, PASS);
			statement = connection.createStatement(); 
			// You can use this command to clear the database and restart from fresh.
			// statement.execute("DROP ALL OBJECTS");

			createTables();  // Create the necessary tables if they don't exist
		} catch (ClassNotFoundException e) {
			System.err.println("JDBC Driver not found: " + e.getMessage());
		}
	}

	private void createTables() throws SQLException {
		String userTable = "CREATE TABLE IF NOT EXISTS cse360users ("
				+ "id INT AUTO_INCREMENT PRIMARY KEY, "
				+ "userName VARCHAR(255) UNIQUE, "
				+ "password VARCHAR(255), "
				+ "email VARCHAR(255), " //email column
				+ "one_time_password VARCHAR(255), " // Stores the one time password
				+ "role VARCHAR(255))";
		statement.execute(userTable);
		
		// Create the invitation codes table
	    String invitationCodesTable = "CREATE TABLE IF NOT EXISTS InvitationCodes ("
	            + "code VARCHAR(255) PRIMARY KEY, "
	    		+ "role VARCHAR(255), "
	            + "isUsed BOOLEAN DEFAULT FALSE)";
	    statement.execute(invitationCodesTable);
	    
	    String questionTable = "CREATE TABLE IF NOT EXISTS questions ("
	    		+ "userName VARCHAR(255) , "
	    		+ "question VARCHAR(255), "
	    		+ "role VARCHAR(255))";
	    statement.execute(questionTable);
	    
	    String answerTable = "CREATE TABLE IF NOT EXISTS answers ("
	    		+ "userName VARCHAR(255) , "
	    		+ "question VARCHAR(255), "
	    		+ "answer VARCHAR (255), "
	    		+ "role VARCHAR(255), "
	    		+ "resolved VARCHAR(255))";
	    statement.execute(answerTable);
	    
	  //Clarifications table
	    String clarificationTable = "CREATE TABLE IF NOT EXISTS clarifications ("
	            + "id INT AUTO_INCREMENT PRIMARY KEY, "
	            + "answerUserName VARCHAR(255), "
	            + "question VARCHAR(255), "
	            + "answer VARCHAR(255), "
	            + "clarifier VARCHAR(255), "
	            + "clarificationText VARCHAR(255), "
	            + "timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP)";
	    statement.execute(clarificationTable);
	}


	// Check if the database is empty
	public boolean isDatabaseEmpty() throws SQLException {
		String query = "SELECT COUNT(*) AS count FROM cse360users";
		ResultSet resultSet = statement.executeQuery(query);
		if (resultSet.next()) {
			return resultSet.getInt("count") == 0;
		}
		return true;
	}

	// Registers a new user in the database.
	public void register(User user) throws SQLException {
		
		System.out.println("Registering user: " + user.getUserName());
	    System.out.println("Password: " + user.getPassword());
	    System.out.println("Role: " + user.getRole());
	    System.out.println("Email: " + user.getEmail());
		
		String insertUser = "INSERT INTO cse360users (userName, password, role, email) VALUES (?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			pstmt.setString(4, user.getEmail());
			pstmt.executeUpdate();
		}
	}
	
	// Adds a question in the database
	public void post(Question question) throws SQLException {
		
		System.out.println("User: " + question.getUserName());
	    System.out.println("Question: " + question.getQuestion());
	    System.out.println("Role: " + question.getRole());
		
		String insertUser = "INSERT INTO questions (userName, question, role) VALUES (?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, question.getUserName());
			pstmt.setString(2, question.getQuestion());
			pstmt.setString(3, question.getRole());
			pstmt.executeUpdate();
		}
	}
	
	// Adds a answer to a question in the database
	public void answer(Answer answer) throws SQLException {
		
		System.out.println("User: " + answer.getUserName());
	    System.out.println("Question: " + answer.getQuestion());
	    System.out.println("Answer: " + answer.getAnswer());
	    System.out.println("Role: " + answer.getRole());
	    System.out.println("Resolved: " + answer.getResolved());
		
		String insertUser = "INSERT INTO answers (userName, question, answer, role, resolved) VALUES (?, ?, ?, ?, ?)";
		try (PreparedStatement pstmt = connection.prepareStatement(insertUser)) {
			pstmt.setString(1, answer.getUserName());
			pstmt.setString(2, answer.getQuestion());
			pstmt.setString(3, answer.getAnswer());
			pstmt.setString(4, answer.getRole());
			pstmt.setString(5, answer.getResolved());
			pstmt.executeUpdate();
		}
	}

	// Validates a user's login credentials.
	public boolean login(User user) throws SQLException {
		String query = "SELECT * FROM cse360users WHERE userName = ? AND password = ? AND role = ?";
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
			pstmt.setString(1, user.getUserName());
			pstmt.setString(2, user.getPassword());
			pstmt.setString(3, user.getRole());
			try (ResultSet rs = pstmt.executeQuery()) {
				return rs.next();
			}
		}
	}
	
	//checks if user is logging in with a valid one time password
	public boolean isOneTimePassword(String username, String password) {
	    String query = "SELECT one_time_password FROM cse360users WHERE userName = ?";

	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, username);
	        ResultSet rs = stmt.executeQuery();
	        if (rs.next()) {
	            String otp = rs.getString("one_time_password");
	            return otp != null && otp.equals(password); // Check if it matches
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // Return false if it dont match
	}
	
	public boolean resetPassword(String username, String newPassword) {
		String query = "UPDATE cse360users SET password = ?, one_time_password = NULL WHERE userName = ?";
		
		try(PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, newPassword);
			stmt.setString(2, username);
			int updated = stmt.executeUpdate();
			return updated > 0; // If pass was updated right then return true
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false; // if update did not work
	}
	
	// Checks if a user already exists in the database based on their userName.
	public boolean doesUserExist(String userName) {
	    String query = "SELECT COUNT(*) FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            // If the count is greater than 0, the user exists
	            return rs.getInt(1) > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false; // If an error occurs, assume user doesn't exist
	}
	
	
	public String getUserEmail(String userName) {
	    String query = "SELECT email FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            return rs.getString("email");
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null;
	}
	
	// Retrieves the role of a user from the database using their UserName.
	public String getUserRole(String userName) {
	    String query = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userName);
	        ResultSet rs = pstmt.executeQuery();
	        
	        if (rs.next()) {
	            return rs.getString("role"); // Return the role if user exists
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return null; // If no user exists or an error occurs
	}
	
	// Generates a new invitation code and inserts it into the database.
	public String generateInvitationCode(ObservableList<String> selected_role) {
	    String code = UUID.randomUUID().toString().substring(0, 4); // Generate a random 4-character code
	    String role = getRoleFromAdmin(selected_role.toString());
	    String query = "INSERT INTO InvitationCodes (code) VALUES (?)";
	    
	    code = role + code;
	    
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }

	    return code;
	}
	
	// Generates a prefix to the code to indicate roles
	public String getRoleFromAdmin(String role) {
		role = role.toLowerCase();
		String prefix = "";
		if (role.contains("student")) {
			prefix = prefix + "!";
		}
		if (role.contains("staff")) {
			prefix = prefix + "%";
		}
		if (role.contains("reviewer")) {
			prefix = prefix + "$";
		}
		if (role.contains("instructor")) {
			prefix = prefix + "#";
		}
		if (role.contains("admin")){
			prefix = prefix + "@";
		}
		return prefix;
	}
	
	//generates one time password obviously
	public String generateOneTimePassword(String username) {
		String tempPassword = UUID.randomUUID().toString().substring(0, 8); //Generates random 8-char password
		String query = "UPDATE cse360users SET one_time_password = ? WHERE userName = ?";
		
		try(PreparedStatement stmt = connection.prepareStatement(query)) {
			stmt.setString(1, tempPassword);
			stmt.setString(2, username);
			int updated = stmt.executeUpdate();
			if (updated > 0) {
				return tempPassword; // Returns the one time password
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null; // Return null if the update didnt work
	}
	
	//assign roles as admin
	public boolean assignRole(String userName, String role) {
		
		
		String checkRoleQuery = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement checkStmt = connection.prepareStatement(checkRoleQuery)) {
	        checkStmt.setString(1, userName);
	        ResultSet rs = checkStmt.executeQuery();
	        if (rs.next() && rs.getString("role").equals("admin")) {
	            return false; // Prevent role change for admin users
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false;
	    }
		
	    String query = "UPDATE cse360users SET role = ? WHERE userName = ?";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, role);
	        stmt.setString(2, userName);
	        return stmt.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; //an issue occurs return false
	    }
		
	}
	
	public boolean updateQuestion(String original, String overRidden) {
		
	    String query = "UPDATE questions SET question = ? WHERE question = ?";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, overRidden);
	        stmt.setString(2, original);
	        return stmt.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; //an issue occurs return false
	    }
	}
	
	public boolean updateAnswer(String original, String overRidden) {
		
	    String query = "UPDATE answers SET question = ? WHERE question = ?";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, overRidden);
	        stmt.setString(2, original);
	        return stmt.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; //an issue occurs return false
	    }
	}
	
	public boolean updateAnswerBox(String original, String overRidden, String question, String user) {
		
	    String query = "UPDATE answers SET answer = ?, resolved = ? WHERE question = ? AND answer = ? AND userName = ?";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, overRidden);
	        stmt.setString(2, "");
	        stmt.setString(3, question);
	        stmt.setString(4, original);
	        stmt.setString(5, user);
	        return stmt.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; //an issue occurs return false
	    }
	}
	
	
	public boolean deleteAnswer(String user, String question) {
		  
	    String query = "DELETE FROM answers WHERE userName = ? AND question = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user);
	        pstmt.setString(2, question);
	        int deleted = pstmt.executeUpdate();
	        return deleted > 0; // Return true if a row was deleted
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	//remove rols as admin
	public boolean removeRole(String userName) {
	    String checkRoleQuery = "SELECT role FROM cse360users WHERE userName = ?";
	    String removeQuery = "UPDATE cse360users SET role = NULL WHERE userName = ? AND role <> 'admin'";

	    try (PreparedStatement checkRoleStmt = connection.prepareStatement(checkRoleQuery)) {
	        checkRoleStmt.setString(1, userName);
	        ResultSet roleResult = checkRoleStmt.executeQuery();

	        if (roleResult.next()) {
	            String role = roleResult.getString("role");
	            if ("admin".equals(role)) {
	                return false; // cant remove admin role from any user
	            }
	        }

	        try (PreparedStatement stmt = connection.prepareStatement(removeQuery)) {
	            stmt.setString(1, userName);
	            return stmt.executeUpdate() > 0;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	
	//-----------------------deleteUsers method--------------------------//
	public boolean deleteUser(String adminUserName, String userToDelete) {
	    if (adminUserName.equals(userToDelete)) {
	        return false; // cant delete self
	    }
	    
	    // Check if the user to delete is an admin
	    String checkRoleQuery = "SELECT role FROM cse360users WHERE userName = ?";
	    try (PreparedStatement checkStmt = connection.prepareStatement(checkRoleQuery)) {
	        checkStmt.setString(1, userToDelete);
	        ResultSet result = checkStmt.executeQuery();
	        if (result.next() && result.getString("role").equals("admin")) {
	            return false; // Prevent deletion of other admins
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    
	    
	    String query = "DELETE FROM cse360users WHERE userName = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, userToDelete);
	        int deleted = pstmt.executeUpdate();
	        return deleted > 0; // Return true if a row was deleted
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}

	
	//---------Validates an invitation code to check if it is unused-------------//
	public boolean validateInvitationCode(String code) {
	    String query = "SELECT * FROM InvitationCodes WHERE code = ? AND isUsed = FALSE";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        ResultSet rs = pstmt.executeQuery();
	        if (rs.next()) {
	            // Mark the code as used
	            markInvitationCodeAsUsed(code);
	            return true;
	        }
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	// Marks the invitation code as used in the database.
	private void markInvitationCodeAsUsed(String code) {
	    String query = "UPDATE InvitationCodes SET isUsed = TRUE WHERE code = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, code);
	        pstmt.executeUpdate();
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	}
	
	//Retrieves all users and inf0
	public List<User> getAllUsers() throws SQLException {
		List<User> users = new ArrayList<>();
		String query = "SELECT userName, email, role FROM cse360users";
		
		try (Statement stmt = connection.createStatement();
				ResultSet results = stmt.executeQuery(query)) {
			while (results.next()) {
				String username = results.getString("userName");
				String email = results.getString("email");
				String role = results.getString("role");
				users.add(new User(username, "", role, email)); //does not show a password
			}
		}
		return users;
	}
	
	//Retrieves questions that a certain user has posted
	public List<Question> getAllUsersQuestions(String user) throws SQLException {
		List<Question> questions = new ArrayList<>();
		String query = "SELECT userName, question, role FROM questions WHERE userName = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user);
	        ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String username = rs.getString("userName");
				String question = rs.getString("question");
				String role = rs.getString("role");
				questions.add(new Question(username, question, role)); //does not show a password
			}
		}
		return questions;
	}
	
	//Retrieves all answers for a question
	public List<Answer> getAnswers(String question) throws SQLException {
		List<Answer> answers = new ArrayList<>();
		String query = "SELECT userName, question, answer, role, resolved FROM answers WHERE question = ?";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, question);
	        ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String username = rs.getString("userName");
				String questions = rs.getString("question");
				String answer = rs.getString("answer");
				String role = rs.getString("role");
				String resolved = rs.getString("resolved");
				answers.add(new Answer(username, questions, answer, role, resolved)); //does not show a password
			}
		}
		return answers;
	}
	
	// Get all questions posted
	public List<Question> getAllQuestions() throws SQLException {
		List<Question> questions = new ArrayList<>();
		String query = "SELECT userName, question, role FROM questions";
		
		try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				String username = rs.getString("userName");
				String question = rs.getString("question");
				String role = rs.getString("role");
				questions.add(new Question(username, question, role)); //does not show a password
			}
		}
		return questions;
	}
	
	//-----------------------deleteQuesions method--------------------------//
	public boolean deleteQuestion(String user, String question) {
  
	    String query = "DELETE FROM questions WHERE userName = ? AND question = ?";
	    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
	        pstmt.setString(1, user);
	        pstmt.setString(2, question);
	        int deleted = pstmt.executeUpdate();
	        return deleted > 0; // Return true if a row was deleted
	    } catch (SQLException e) {
	        e.printStackTrace();
	    }
	    return false;
	}
	
	public boolean setAnswerAsResolved(String answer, String user) {
		
	    String query = "UPDATE answers SET resolved = ? WHERE answer = ? AND userName = ?";
	    try (PreparedStatement stmt = connection.prepareStatement(query)) {
	        stmt.setString(1, " (resolved)");
	        stmt.setString(2, answer);
	        stmt.setString(3, user);
	        return stmt.executeUpdate() > 0;
	    } catch (SQLException e) {
	        e.printStackTrace();
	        return false; //an issue occurs return false
	    }
	}
	
	public Question chosenQuestion(String user, String question) throws SQLException {
		String query = "SELECT userName, question, role FROM questions WHERE userName = ? AND question = ?";
		Question questions = null;
			try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, user);
		        pstmt.setString(2, question);
		        ResultSet rs = pstmt.executeQuery();
		        if (rs.next()) {
					String username = rs.getString("userName");
					String question1 = rs.getString("question");
					String role = rs.getString("role");
					questions = new Question(username, question1, role);
		        }
			}
		return questions;
	}
	
	//---------------------------Clarification------------------------------------------//
		public boolean insertClarification(Clarification clarification) throws SQLException {
		    String query = "INSERT INTO clarifications "
		                 + "(answerUserName, question, answer, clarifier, clarificationText) "
		                 + "VALUES (?, ?, ?, ?, ?)";

		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, clarification.getAnswerUserName());
		        pstmt.setString(2, clarification.getQuestion());
		        pstmt.setString(3, clarification.getAnswer());
		        pstmt.setString(4, clarification.getClarifier());
		        pstmt.setString(5, clarification.getClarificationText());
		        return pstmt.executeUpdate() > 0;
		    }
		}

		public List<Clarification> getClarifications(String answerUserName, String question, String answer) throws SQLException {
		    List<Clarification> clarifications = new ArrayList<Clarification>();
		    String query = "SELECT clarifier, clarificationText FROM clarifications "
		                 + "WHERE answerUserName = ? AND question = ? AND answer = ?";

		    try (PreparedStatement pstmt = connection.prepareStatement(query)) {
		        pstmt.setString(1, answerUserName);
		        pstmt.setString(2, question);
		        pstmt.setString(3, answer);
		        ResultSet rs = pstmt.executeQuery();
		        while (rs.next()) {
		            String clarifier = rs.getString("clarifier");
		            String clarificationText = rs.getString("clarificationText");
		            clarifications.add(
		                new Clarification(answerUserName, question, answer, clarifier, clarificationText)
		            );
		        }
		    }
		    return clarifications;
		}

	

	// Closes the database connection and statement.
	public void closeConnection() {
		try{ 
			if(statement!=null) statement.close(); 
		} catch(SQLException se2) { 
			se2.printStackTrace();
		} 
		try { 
			if(connection!=null) connection.close(); 
		} catch(SQLException se){ 
			se.printStackTrace(); 
		} 
	}

}
