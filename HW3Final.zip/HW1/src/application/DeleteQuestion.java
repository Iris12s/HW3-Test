package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DeleteQuestion {
	private final DatabaseHelper databaseHelper;

    public DeleteQuestion(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user, String original) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("View all questions");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Input field for question
        Label questionField = new Label("Delete question:");
        
        Label originalQuestion = new Label(original);
        
        Label errorLabel = new Label("");
        
        // Update Question
        Button deleteQuestion = new Button("Delete");
        deleteQuestion.setOnAction(a -> {
        	
        	int index = original.indexOf(":");
        	
        	int hash = original.lastIndexOf("#");
        	
        	String questionName = original.substring(index + 2);
        	
        	String userName = original.substring(0, index);
        	
        	databaseHelper.deleteQuestion(userName, questionName);
        	databaseHelper.deleteAnswer(userName, questionName);
        	
        	new ViewingUserQuestion(databaseHelper).show(primaryStage, user);
        });


        
        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout.getChildren().addAll(titleLabel, questionField, originalQuestion, deleteQuestion, errorLabel, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Viewing All Questions");
    }
}
