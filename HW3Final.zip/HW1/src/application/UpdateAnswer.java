package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UpdateAnswer {
	private final DatabaseHelper databaseHelper;

    public UpdateAnswer(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user, String question, String original, Question postedQuestion) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Edit Answer");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Input field for question
        Label questionField = new Label("Update Answer:");

        TextField updateField = new TextField();
        updateField.setPromptText("Enter updated answer:");
        
        Label originalQuestion = new Label(question);
        
        Label originalAnswer = new Label(original);
        
        Label errorLabel = new Label("");
        
        // Update Question
        Button updateAnswer = new Button("Update answer");
        updateAnswer.setOnAction(a -> {
        	
        	int index = original.indexOf(":");
        	String originalAnswers = original.substring(index + 2);
        	String newAnswer = updateField.getText();
        	
        	System.out.println(originalAnswers);
        	System.out.println(question);
        	System.out.println(newAnswer);
        	
        	if (originalAnswers.contains("(resolved)")) {
        		int space = originalAnswers.lastIndexOf(" ");
        		originalAnswers = originalAnswers.substring(0, space);
        	}
        	
        	System.out.println(originalAnswers);
        	
        	if (updateField.getText() == null) {
        		errorLabel.setText("Please enter an updated answer");
        		return;
        	}

        	databaseHelper.updateAnswerBox(originalAnswers, newAnswer, question, user.getUserName());
        	
        	new PresentQuestions(databaseHelper).show(primaryStage, postedQuestion, user);
        });


        
        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout.getChildren().addAll(titleLabel, questionField, originalQuestion, originalAnswer, updateField, updateAnswer, errorLabel, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Viewing All Questions");
    }
}
