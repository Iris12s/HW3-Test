package application;

public class Question {
	
    private String userName;
    private String question;
    private String role;

	    // Constructor to initialize a new User object with userName, password, and role.
	    public Question( String userName, String question, String role) {
	        this.userName = userName;
	        this.question = question;
	        this.role = role;
	    }
	    
	    public String getUserName() { return userName; }
	    public String getQuestion() { return question; }
	    public String getRole() { return role; }
}



