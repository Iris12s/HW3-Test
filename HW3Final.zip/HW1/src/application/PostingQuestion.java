package application;

import java.sql.SQLException;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PostingQuestion {
    private final DatabaseHelper databaseHelper;

    public PostingQuestion(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Post Question");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Input field for question
        TextField questionField = new TextField();
        questionField.setPromptText("Enter question:");
        
        Label errorLabel = new Label("");

        // Delete button
        Button postQuestion = new Button("Post");
        postQuestion.setOnAction(a -> { 
        	if (questionField.getText() == null) {
        		errorLabel.setText("Please enter a question");
        	}
        	String questionFill = questionField.getText();
        	Question question = new Question(user.getUserName(), questionFill, user.getRole());
        	try {
				databaseHelper.post(question);
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	
        	new PresentQuestions(databaseHelper).show(primaryStage, question, user);
        });


        
        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout.getChildren().addAll(titleLabel, questionField, postQuestion, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Posting Question");
    }
}
