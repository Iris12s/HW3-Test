package application;

public class Clarification {

    private String answerUserName;
    private String question;
    private String answer;
    private String clarifier;
    private String clarificationText;

    public Clarification(String answerUserName, String question, String answer, String clarifier, String clarificationText) {
        this.answerUserName = answerUserName;
        this.question = question;
        this.answer = answer;
        this.clarifier = clarifier;
        this.clarificationText = clarificationText;
    }

    public String getAnswerUserName() { return answerUserName; }
    public String getQuestion() { return question; }
    public String getAnswer() { return answer; }
    public String getClarifier() { return clarifier; }
    public String getClarificationText() { return clarificationText; }
}
