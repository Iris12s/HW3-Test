package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class ViewingAllQuestions {
	private final DatabaseHelper databaseHelper;

    public ViewingAllQuestions(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("View all questions");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Input field for question
        Label questionField = new Label("Question List:");
        
        ListView<String> questionList = new ListView<>();

        try {
            List<Question> questions = databaseHelper.getAllQuestions();
            for (Question question : questions) {
            	List<Answer> answers = databaseHelper.getAnswers(question.getQuestion());
            	int numAnswers = 0;
            	String resolution = "";
                for (Answer answer : answers) {
                	numAnswers += 1;
                	if (answer.getResolved() != "") {
                		resolution = "Solved";
                	}
                }
                if (resolution.equals("Solved")) {
                questionList.getItems().add(0, question.getUserName() + ": " + question.getQuestion() + " # of Answers: " + numAnswers + " "  + resolution);
                }
                else {
                	questionList.getItems().add(question.getUserName() + ": " + question.getQuestion() + " # of Answers: " + numAnswers + " "  + resolution);
                }
            }
        } catch (SQLException e) {
            questionList.getItems().add("Error fetching questions.");
            e.printStackTrace();
        }
        
        Label errorLabel = new Label("");

        // View question
        Button viewQuestion = new Button("View");
        viewQuestion.setOnAction(a -> { 
        	if (questionList.getSelectionModel().getSelectedItem() == null) {
        		errorLabel.setText("Please choose a question to view");
        		return;
        	}
        	String questionFill = questionList.getSelectionModel().getSelectedItem();
        	
        	int index = questionFill.indexOf(":");
        	
        	int indexHash = questionFill.lastIndexOf("#");
        	
        	String userName = questionFill.substring(0, index);
        	
        	String questionName = questionFill.substring(index + 2, indexHash - 1);
        	
        	Question question = null;
			try {
				question = databaseHelper.chosenQuestion(userName, questionName);
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	
        	new PresentQuestions(databaseHelper).show(primaryStage, question, user);
        });


        
        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout.getChildren().addAll(titleLabel, questionField, questionList, viewQuestion, errorLabel, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Viewing All Questions");
    }
}
