package application;

import java.sql.SQLException;
import java.util.List;
import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SearchQuestion {
    private final DatabaseHelper databaseHelper;

    public SearchQuestion(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Search Question");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        TextField searchField = new TextField();
        searchField.setPromptText("Enter question to search:");
        
        ListView<String> questionListView = new ListView<>();
        Label errorLabel = new Label("");

        try {
            List<Question> questions = databaseHelper.getAllQuestions();
            if (questions.isEmpty()) {
                errorLabel.setText("Error fetching questions.");
            } else {
                for (Question question : questions) {
                	List<Answer> answers = databaseHelper.getAnswers(question.getQuestion());
                	int numAnswers = 0;
                	String resolution = "";
                    for (Answer answer : answers) {
                    	numAnswers += 1;
                    	if (answer.getResolved() != "") {
                    		resolution = "Solved";
                    	}
                    }
                    if (resolution.equals("Solved")) {
                    questionListView.getItems().add(0, question.getUserName() + ": " + question.getQuestion() + " # of Answers: " + numAnswers + " "  + resolution);
                    }
                    else {
                    	questionListView.getItems().add(question.getUserName() + ": " + question.getQuestion() + " # of Answers: " + numAnswers + " "  + resolution);
                    }
                }
            }
        } catch (SQLException e) {
            errorLabel.setText("Error fetching questions.");
            e.printStackTrace();
        }

        searchField.textProperty().addListener((observable, oldValue, newValue) -> {
            questionListView.getItems().clear();
            try {
                List<Question> filteredQuestions = databaseHelper.getAllQuestions();
                for (Question question : filteredQuestions) {
                    if (question.getQuestion().toLowerCase().contains(newValue.toLowerCase())) {
                    	List<Answer> answers = databaseHelper.getAnswers(question.getQuestion());
                    	int numAnswers = 0;
                    	String resolution = "";
                        for (Answer answer : answers) {
                        	numAnswers += 1;
                        	if (answer.getResolved() != "") {
                        		resolution = "Solved";
                        	}
                        }
                        questionListView.getItems().add(question.getUserName() + ": " + question.getQuestion() + " # of Answers: " + numAnswers + " "  + resolution);
                    }
                }
            } catch (SQLException e) {
                errorLabel.setText("Error fetching questions.");
                e.printStackTrace();
            }
        });

        // View question
        Button viewQuestion = new Button("View");
        viewQuestion.setOnAction(a -> { 
        	if (questionListView.getSelectionModel().getSelectedItem() == null) {
        		errorLabel.setText("Please choose a question to view");
        		return;
        	}
        	String questionFill = questionListView.getSelectionModel().getSelectedItem();
        	
        	int index = questionFill.indexOf(":");
        	
        	int indexHash = questionFill.lastIndexOf("#");
        	
        	String userName = questionFill.substring(0, index);
        	
        	String questionName = questionFill.substring(index + 2, indexHash - 1);
        	
        	Question question = null;
			try {
				question = databaseHelper.chosenQuestion(userName, questionName);
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	
        	new PresentQuestions(databaseHelper).show(primaryStage, question, user);
        });


        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout.getChildren().addAll(titleLabel, searchField, questionListView, viewQuestion, errorLabel, backButton);
        Scene searchScene = new Scene(layout, 800, 400);
        primaryStage.setScene(searchScene);
        primaryStage.setTitle("Search Question");
    }
}
