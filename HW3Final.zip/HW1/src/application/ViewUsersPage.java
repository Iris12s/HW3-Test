package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;
import java.util.List;


 //ViewUsersPage displays a list of all users in the system.
 
public class ViewUsersPage {
    private final DatabaseHelper databaseHelper;

    public ViewUsersPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("All Users");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        ListView<String> userList = new ListView<>();

        try {
            List<User> users = databaseHelper.getAllUsers();
            for (User user : users) {
            	userList.getItems().add(user.getUserName() + " | " + user.getEmail() + " | " + user.getRole());
            }
        } catch (SQLException e) {
            userList.getItems().add("Error fetching users.");
            e.printStackTrace();
        }

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new AdminHomePage(databaseHelper).show(primaryStage));

        layout.getChildren().addAll(titleLabel, userList, backButton);

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("View Users");
    }
}
