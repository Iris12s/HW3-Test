package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


/**
 * AdminPage class represents the user interface for the admin user.
 * This page displays a simple welcome message for the admin.
 */

public class AdminHomePage {
	/**
     * Displays the admin page in the provided primary stage.
     * @param primaryStage The primary stage where the scene will be displayed.
     */
	private final DatabaseHelper databaseHelper;

    public AdminHomePage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }
    
    public void show(Stage primaryStage) {
    	VBox layout = new VBox(10); //10 pixels to space UI elements out, so no overlapping
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    
	    // label to display the welcome message for the admin
	    Label adminLabel = new Label("Hello, Admin!");
	    adminLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	    
	    //------------- Buttons--------------------//        
	    Button manageRolesButton = new Button("Manage User Roles");
        manageRolesButton.setOnAction(e -> new ManageRolesPage(databaseHelper).show(primaryStage));
        
        Button deleteUserPageButton = new Button("Delete User");
        deleteUserPageButton.setOnAction(e -> new DeleteUserPage(databaseHelper, "admin_username").show(primaryStage));

        Button resetPasswordButton = new Button("Reset User Password");
        resetPasswordButton.setOnAction(e -> new ResetUsersPasswordPage(databaseHelper).show(primaryStage));

        Button viewUsersButton = new Button("View All Users");
        viewUsersButton.setOnAction(e -> new ViewUsersPage(databaseHelper).show(primaryStage));

        Button logOutButton = new Button("Logout");
        logOutButton.setOnAction(e -> new SetupLoginSelectionPage(databaseHelper).show(primaryStage));

	    Button logOut = new Button("Logout");
	    logOut.setOnAction(a -> {
	    	new SetupLoginSelectionPage(databaseHelper).show(primaryStage);
	    	
	   
	    
	    });
	    //displays layout/UI 
	    layout.getChildren().addAll(
	    		adminLabel,
	    		manageRolesButton,
	    		resetPasswordButton,
	    		viewUsersButton,
	    		logOutButton,
	    		deleteUserPageButton
	    		);

	    Scene adminScene = new Scene(layout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(adminScene);
	    primaryStage.setTitle("Admin Page");
    }
}