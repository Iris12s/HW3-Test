package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UpdateQuestionName {
	private final DatabaseHelper databaseHelper;

    public UpdateQuestionName(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User user, String original) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("View all questions");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Input field for question
        Label questionField = new Label("Update Question:");

        TextField updateField = new TextField();
        updateField.setPromptText("Enter updated question:");
        
        Label originalQuestion = new Label(original);
        
        Label errorLabel = new Label("");
        
        // Update Question
        Button updateQuestion = new Button("Update Question");
        updateQuestion.setOnAction(a -> {
        	
        	int index = original.indexOf(":");
        	
        	int indexHash = original.lastIndexOf("#");
        	
        	String questionName = original.substring(index + 2, indexHash - 1);
        	
        	if (updateField.getText() == null) {
        		errorLabel.setText("Please enter an updated question");
        		return;
        	}
        	
        	String newQuestion = updateField.getText();
        	
        	databaseHelper.updateQuestion(questionName, newQuestion);
        	databaseHelper.updateAnswer(questionName, newQuestion);
        	
        	new ViewingUserQuestion(databaseHelper).show(primaryStage, user);
        });


        
        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout.getChildren().addAll(titleLabel, questionField, originalQuestion, updateField, updateQuestion, errorLabel, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Viewing All Questions");
    }
}
