package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * ManageRolesPage allows admins to assign or remove roles for users.
 */
public class ManageRolesPage {
    private final DatabaseHelper databaseHelper;

    public ManageRolesPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Manage User Roles");
        titleLabel.setStyle("-fx-font-size: 18px; -fx-font-weight: bold;");

        TextField userField = new TextField();
        userField.setPromptText("Enter username");
        userField.setMaxWidth(250);

        ComboBox<String> roleSelection = new ComboBox<>();
        roleSelection.getItems().addAll("student", "staff", "reviewer", "instructor");

        Button assignRoleButton = new Button("Assign Role");
        assignRoleButton.setOnAction(e -> {
            String username = userField.getText().trim();
            String role = roleSelection.getValue();
            if (!username.isEmpty() && role != null) {
                if (databaseHelper.assignRole(username, role)) {
                    new Alert(Alert.AlertType.INFORMATION, "Role assigned successfully!").showAndWait();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Error assigning role.").showAndWait();
                }
            }
        });

        Button removeRoleButton = new Button("Remove Role");
        removeRoleButton.setOnAction(e -> {
            String username = userField.getText().trim();
            if (!username.isEmpty()) {
                if (databaseHelper.removeRole(username)) {
                    new Alert(Alert.AlertType.INFORMATION, "Role removed successfully!").showAndWait();
                } else {
                    new Alert(Alert.AlertType.ERROR, "Cannot remove admin role or user not found.").showAndWait();
                }
            }
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> new AdminHomePage(databaseHelper).show(primaryStage));

        layout.getChildren().addAll(titleLabel, userField, roleSelection, assignRoleButton, removeRoleButton, backButton);

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Manage Roles");
    }
}
