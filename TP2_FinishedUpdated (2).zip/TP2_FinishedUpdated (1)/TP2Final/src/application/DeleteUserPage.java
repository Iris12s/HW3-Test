package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class DeleteUserPage {
    private final DatabaseHelper databaseHelper;
    private final String adminUserName; // Admin username to prevent self-deletion

    public DeleteUserPage(DatabaseHelper databaseHelper, String adminUserName) {
        this.databaseHelper = databaseHelper;
        this.adminUserName = adminUserName;
    }

    public void show(Stage primaryStage) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Delete Account");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        // Input field for username
        TextField userToDeleteField = new TextField();
        userToDeleteField.setPromptText("Enter username to delete");

        // Delete button
        Button deleteUserButton = new Button("Delete User");
        deleteUserButton.setOnAction(a -> {
            String userToDelete = userToDeleteField.getText().trim();
            if (!userToDelete.isEmpty()) {
                if (userToDelete.equals(adminUserName)) {
                    Alert alert = new Alert(Alert.AlertType.ERROR, "You cannot delete your own account.");
                    alert.showAndWait();
                    return;
                }

                Alert confirm = new Alert(Alert.AlertType.CONFIRMATION,
                        "Are you sure you want to delete " + userToDelete + "? Type 'Yes' to confirm.",
                        ButtonType.OK, ButtonType.CANCEL);
                confirm.showAndWait();

                if (confirm.getResult() == ButtonType.OK) {
                    TextInputDialog inputDialog = new TextInputDialog();
                    inputDialog.setTitle("Confirm Deletion");
                    inputDialog.setHeaderText(null);
                    inputDialog.setContentText("Type 'Yes' to confirm deletion:");

                    inputDialog.showAndWait().ifPresent(response -> {
                        if (response.equalsIgnoreCase("Yes")) {
                            boolean success = databaseHelper.deleteUser(adminUserName, userToDelete);
                            if (success) {
                                Alert alert = new Alert(Alert.AlertType.INFORMATION, "User deleted.");
                                alert.showAndWait();
                            } else {
                                Alert alert = new Alert(Alert.AlertType.ERROR, "User could not be deleted.");
                                alert.showAndWait();
                            }
                        }
                    });
                }
            } else {
                Alert alert = new Alert(Alert.AlertType.ERROR, "Username field cannot be empty.");
                alert.showAndWait();
            }
        });

        
        Button backButton = new Button("Back to Admin Home");
        backButton.setOnAction(a -> new AdminHomePage(databaseHelper).show(primaryStage));

        layout.getChildren().addAll(titleLabel, userToDeleteField, deleteUserButton, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Delete User");
    }
}
