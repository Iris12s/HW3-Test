package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.SQLException;
import java.util.List;

public class ViewClarifications {
    private final DatabaseHelper databaseHelper;

    public ViewClarifications(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, Answer answer, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Clarifications for the Answer");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label answerLabel = new Label("Answer: " + answer.getAnswer());

        ListView<String> clarificationList = new ListView<String>();
        try {
            List<Clarification> clarifications = databaseHelper.getClarifications(
                answer.getUserName(), answer.getQuestion(), answer.getAnswer()
            );
            for (Clarification cl : clarifications) {
                clarificationList.getItems().add(
                    cl.getClarifier() + ": " + cl.getClarificationText()
                );
            }
        } catch (SQLException e) {
            clarificationList.getItems().add("Error fetching clarifications.");
            e.printStackTrace();
        }

        Button backButton = new Button("Back");
        backButton.setOnAction(a -> {
            new PresentQuestions(databaseHelper).show(
                primaryStage,
                new Question(answer.getUserName(), answer.getQuestion(), answer.getRole()),
                user
            );
        });

        layout.getChildren().addAll(titleLabel, answerLabel, clarificationList, backButton);

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("View Clarifications");
    }
}
