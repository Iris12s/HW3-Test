package application;

public class Answer {
		
	    private String userName;
	    private String question;
	    private String role;
	    private String answer;
	    private String resolved;

		    // Constructor to initialize a new User object with userName, password, and role.
		    public Answer( String userName, String question, String answer, String role, String resolved) {
		        this.userName = userName;
		        this.question = question;
		        this.role = role;
		        this.answer = answer;
		        this.resolved = resolved;
		    }
		    
		    public String getUserName() { return userName; }
		    public String getQuestion() { return question; }
		    public String getRole() { return role; }
		    public String getAnswer() { return answer; }	
		    public String getResolved() { return resolved; }
}

