package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.application.Platform;
import databasePart1.*;

/**
 * The WelcomeLoginPage class displays a welcome screen for authenticated users.
 * It allows users to navigate to their respective pages based on their role or quit the application.
 */
public class WelcomeLoginPage {
	
	private final DatabaseHelper databaseHelper;

    public WelcomeLoginPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }
    public void show( Stage primaryStage, User user) {
    	
    	VBox layout = new VBox(5);
	    layout.setStyle("-fx-alignment: center; -fx-padding: 20;");
	    
	    Label welcomeLabel = new Label("Welcome!!");
	    welcomeLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
	    
	    Label roleLabel = new Label(user.getRole());
	    
    	ComboBox<String> all_role = new ComboBox<>();
	    all_role.getItems().addAll("student", "reviewer", "instructor", "staff", "admin");
	    all_role.setPromptText("Select role");
	    
	    Label error = new Label("");
	   
	    // Button to navigate to the user's respective page based on their role
	    Button continueButton = new Button("Continue to your Page");
	    continueButton.setOnAction(a -> {
		    
	    	String role =user.getRole();
	    	System.out.println(role);
	    	String selected_role = all_role.getSelectionModel().getSelectedItem();
	    	
	    	if (role.length() > 4) {
	    		if (selected_role == null) {
	    			error.setText("No role selected. Please choose one.");
	    		}
	    		else if(role.contains("adm") && selected_role.contains("admin")) {
		    		new AdminHomePage(databaseHelper).show(primaryStage);
		    	}
	    		else if(role.contains("stu") && selected_role.contains("student")) {
		    		new StudentHomePage(databaseHelper).show(primaryStage, user);
		    	}
	    		else if(role.contains("rev") && selected_role.contains("reviewer")) {
		    		new ReviewerHomePage(databaseHelper).show(primaryStage);
		    	}
	    		else if(role.contains("ins") && selected_role.contains("instructor")) {
		    		new InstructorHomePage(databaseHelper).show(primaryStage);
		    	}
	    		else if(role.contains("sta") && selected_role.contains("staff")) {
		    		new StaffHomePage(databaseHelper).show(primaryStage);
		    	}
	    	}
	    	else if (role.length() == 4){
	    		if(role.contains("adm")) {
		    		new AdminHomePage(databaseHelper).show(primaryStage);
		    	}
		    	else if(role.contains("stu")) {
		    		new StudentHomePage(databaseHelper).show(primaryStage, user);
		    	}
		    	else if(role.contains("rev")) {
		    		new ReviewerHomePage(databaseHelper).show(primaryStage);
		    	}
		    	else if(role.contains("ins")) {
		    		new InstructorHomePage(databaseHelper).show(primaryStage);
		    	}
		    	else if(role.contains("sta")) {
		    		new StaffHomePage(databaseHelper).show(primaryStage);
		    	}
	    	}
	    });
	    
	    // Button to quit the application
	    Button quitButton = new Button("Quit");
	    quitButton.setOnAction(a -> {
	    	databaseHelper.closeConnection();
	    	Platform.exit(); // Exit the JavaFX application
	    });
	    
	    layout.getChildren().addAll(welcomeLabel,continueButton,all_role, roleLabel, error, quitButton);
	    
	    // "Invite" button for admin to generate invitation codes
	    if ("admin".equals(user.getRole())) {
            Button inviteButton = new Button("Invite");
            inviteButton.setOnAction(a -> {
                new InvitationPage().show(databaseHelper, primaryStage);
            });
            layout.getChildren().add(3, inviteButton);
        }

	    Scene welcomeScene = new Scene(layout, 800, 400);

	    // Set the scene to primary stage
	    primaryStage.setScene(welcomeScene);
	    primaryStage.setTitle("Welcome Page");
    }
}