package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import databasePart1.DatabaseHelper;

public class ResetPasswordPage {
	private final DatabaseHelper databaseHelper;
	private final String username;
	
	public ResetPasswordPage(DatabaseHelper databaseHelper, String username) {
		this.databaseHelper = databaseHelper;
		this.username = username;
	}
	
	public void show(Stage mainStage) {
		Label instruction = new Label("Create a new password:");
		
		PasswordField newPasswordField = new PasswordField();
		newPasswordField.setPromptText("New password");
		
		Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

		
		Button resetButton = new Button("Reset Password");
		resetButton.setOnAction(a -> {
			String newPassword = newPasswordField.getText();
			
			
			//TODO FIX : the following must utilize passwor evaluator and display error messages
			
		String validationMessage = PasswordEvaluator.evaluatePassword(newPassword);
			
			if(!validationMessage.isEmpty()) {
				errorLabel.setText(validationMessage); //show error in validity of password
				return;
			}
			
			if (databaseHelper.resetPassword(username, newPassword)) {
                errorLabel.setStyle("-fx-text-fill: green;");
                errorLabel.setText("Password reset successful. Please log in again."); 
			//alert logic after this can be deleted it is just a placeholder format. (only checks if pass is equal to 8 chars)
		
			
				if (databaseHelper.resetPassword(username, newPassword)) {
				Alert alert = new Alert(Alert.AlertType.INFORMATION, "Password reset success. Please log in again.");
				alert.showAndWait();
				
				new UserLoginPage(databaseHelper).show(mainStage);
				
				}else { 
					Alert alert = new Alert(Alert.AlertType.ERROR, "Error resetting password.");
					alert.showAndWait();
				}
			}
		});
		
		VBox layout = new VBox(10, instruction, newPasswordField, resetButton, errorLabel);
		layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
		mainStage.setScene(new Scene(layout, 500, 300));
		mainStage.setTitle("Reset Password");
		mainStage.show();
		
		}
}
		