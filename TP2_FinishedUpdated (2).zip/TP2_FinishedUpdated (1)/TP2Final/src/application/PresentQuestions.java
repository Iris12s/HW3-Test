package application;

import java.sql.SQLException;
import java.util.List;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.scene.layout.Priority;
import javafx.scene.layout.HBox;

public class PresentQuestions {
    private final DatabaseHelper databaseHelper;

    public PresentQuestions(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, Question question, User user) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 1;");
        
        HBox layout2 = new HBox(10);

        Label titleLabel = new Label("Question:");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");
        
        Label questionAsked = new Label(question.getQuestion());
        
        ListView<String> answerList = new ListView<>();
        
        int height = 0;
        
        try {
            List<Answer> answers = databaseHelper.getAnswers(question.getQuestion());
            for (Answer answer : answers) {
            	if (answer.getResolved().equals("")) {
            	answerList.getItems().add(answer.getUserName() + ": " + answer.getAnswer() + answer.getResolved());
            	}
            	else {
            		answerList.getItems().add(0, answer.getUserName() + ": " + answer.getAnswer() + answer.getResolved());
            	}
            	height += 1;
            }
        } catch (SQLException e) {
            answerList.getItems().add("Error fetching answers.");
            e.printStackTrace();
        }

        TextField answerField = new TextField();
        answerField.setPromptText("Enter answer:");
        
        Label errorLabel = new Label("");

        // Delete button
        Button postAnswer = new Button("Post");
        postAnswer.setOnAction(a -> { 
        	if (answerField.getText() == null) {
        		errorLabel.setText("Please enter an answer");
        		return;
        	}
        	String answerFill = answerField.getText();
        	Answer answer = new Answer(user.getUserName(), question.getQuestion(), answerFill, user.getRole(), "");
        	try {
				databaseHelper.answer(answer);
			} catch (SQLException e) {
				e.printStackTrace();
			}
        	
        	new PresentQuestions(databaseHelper).show(primaryStage, question, user);
        	
        });
        
        Button resolve = new Button("Mark answer as resolved");
        resolve.setOnAction(a -> {
        	String answerFill = answerList.getSelectionModel().getSelectedItem();
        	
        	System.out.println(answerFill);
        	System.out.println(question.getUserName());
        	System.out.println(user.getUserName());
        	
        	if (answerList.getSelectionModel().getSelectedItem() == null) {
        		errorLabel.setText("Please select an answer");
        		return;
        	}
        	if (!question.getUserName().equals(user.getUserName())) {
        		errorLabel.setText("You are not the original poster");
        		return;
        	}
        	int broker = answerFill.indexOf(":");
        	String userName = answerFill.substring(0, broker);
        	String answer = answerFill.substring(broker + 2);
        	
        	System.out.println(userName);
        	System.out.println(answer);
        	
        	databaseHelper.setAnswerAsResolved(answer, userName);
        	
        	new PresentQuestions(databaseHelper).show(primaryStage, question, user);
        	
        });
        
        Button updateAnswer = new Button("Update Answer");
        updateAnswer.setOnAction(a -> {
        	
        	
        	if (answerList.getSelectionModel().getSelectedItem() == null) {
        		errorLabel.setText("Please select an answer");
        		return;
        	}
        	
        	String answerFill = answerList.getSelectionModel().getSelectedItem();
        	int broker = answerFill.indexOf(":");
        	String userName = answerFill.substring(0, broker);
        	
        	if (!userName.equals(user.getUserName())) {
        		errorLabel.setText("You are not the original poster of this answer");
        		return;
        	} 
        	
        	

        	
        	new UpdateAnswer(databaseHelper).show(primaryStage, user, question.getQuestion(), answerFill, question);
        });
        
        Button clarify = new Button("Clarify");
        clarify.setOnAction(a -> {
            if (answerList.getSelectionModel().getSelectedItem() == null) {
                errorLabel.setText("Please select an answer to clarify");
                return;
            }
            String answerFill = answerList.getSelectionModel().getSelectedItem();
            int broker = answerFill.indexOf(":");
            if (broker == -1) {
                errorLabel.setText("Selected answer format is invalid");
                return;
            }
            String answerUserName = answerFill.substring(0, broker);
            String answerText = answerFill.substring(broker + 2);
            if (answerText.contains(" (resolved)")) {
                answerText = answerText.replace(" (resolved)", "");
            }
            Answer selectedAnswer = new Answer(answerUserName, question.getQuestion(), answerText, user.getRole(), "");
            new ClarificationPage(databaseHelper).show(primaryStage, user, selectedAnswer);
        });
        
        Button viewClarifications = new Button("View Clarifications");
        viewClarifications.setOnAction(a -> {
            String answerFill = answerList.getSelectionModel().getSelectedItem();
            if (answerFill == null) {
                errorLabel.setText("Please select an answer to view clarifications");
                return;
            }
            int broker = answerFill.indexOf(":");
            if (broker == -1) {
                errorLabel.setText("Selected answer format is invalid");
                return;
            }
            String answerUserName = answerFill.substring(0, broker);
            String answerText = answerFill.substring(broker + 2);
            if (answerText.contains(" (resolved)")) {
                answerText = answerText.replace(" (resolved)", "");
            }
            Answer selectedAnswer = new Answer(answerUserName, question.getQuestion(), answerText, user.getRole(), "");
            new ViewClarifications(databaseHelper).show(primaryStage, selectedAnswer, user);
        });


        
        Button backButton = new Button("Back to Student Home");
        backButton.setOnAction(a -> new StudentHomePage(databaseHelper).show(primaryStage, user));

        layout2.getChildren().addAll(postAnswer, resolve, updateAnswer, clarify, viewClarifications, errorLabel);
        layout.getChildren().addAll(titleLabel, questionAsked, answerList, answerField, layout2, backButton);
        Scene deleteUserScene = new Scene(layout, 800, 400);
        primaryStage.setScene(deleteUserScene);
        primaryStage.setTitle("Delete User");
    }
}
