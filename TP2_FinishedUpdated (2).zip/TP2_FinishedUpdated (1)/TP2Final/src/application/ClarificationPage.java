package application;

import databasePart1.DatabaseHelper;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.SQLException;

public class ClarificationPage {
    private final DatabaseHelper databaseHelper;

    public ClarificationPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage, User clarifier, Answer answer) {
        VBox layout = new VBox(10);
        layout.setStyle("-fx-alignment: center; -fx-padding: 20;");

        Label titleLabel = new Label("Submit Clarification");
        titleLabel.setStyle("-fx-font-size: 16px; -fx-font-weight: bold;");

        Label answerLabel = new Label("Answer: " + answer.getAnswer());

        TextArea clarificationField = new TextArea();
        clarificationField.setPromptText("Enter text here");
        clarificationField.setWrapText(true);
        clarificationField.setPrefRowCount(3);

        Label errorLabel = new Label("");
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");

        Button submitButton = new Button("Submit Clarification");
        submitButton.setOnAction(e -> {
            String clarificationText = clarificationField.getText();
            if (clarificationText == null || clarificationText.trim().isEmpty()) {
                errorLabel.setText("Clarification text cannot be empty.");
                return;
            }
            Clarification clarification = new Clarification(
                answer.getUserName(),
                answer.getQuestion(),
                answer.getAnswer(),
                clarifier.getUserName(),
                clarificationText
            );
            try {
                boolean success = databaseHelper.insertClarification(clarification);
                if (success) {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION, "Clarification submitted successfully.");
                    alert.showAndWait();
                    new PresentQuestions(databaseHelper).show(
                        primaryStage,
                        new Question(answer.getUserName(), answer.getQuestion(), answer.getRole()),
                        clarifier
                    );
                } else {
                    errorLabel.setText("Error submitting clarification.");
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
                errorLabel.setText("Database error while submitting clarification.");
            }
        });

        Button backButton = new Button("Back");
        backButton.setOnAction(e -> {
            new PresentQuestions(databaseHelper).show(
                primaryStage,
                new Question(answer.getUserName(), answer.getQuestion(), answer.getRole()),
                clarifier
            );
        });

        layout.getChildren().addAll(titleLabel, answerLabel, clarificationField, submitButton, errorLabel, backButton);

        Scene scene = new Scene(layout, 800, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Clarification Submission");
    }
}
