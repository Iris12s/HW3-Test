package application;

import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.SQLException;

import databasePart1.*;

/**
 * The UserLoginPage class provides a login interface for users to access their accounts.
 * It validates the user's credentials and navigates to the appropriate page upon successful login.
 */
public class UserLoginPage {
	
    private final DatabaseHelper databaseHelper;

    public UserLoginPage(DatabaseHelper databaseHelper) {
        this.databaseHelper = databaseHelper;
    }

    public void show(Stage primaryStage) {
    	// Input field for the user's userName, password
        TextField userNameField = new TextField();
        userNameField.setPromptText("Enter userName");
        userNameField.setMaxWidth(250);

        PasswordField passwordField = new PasswordField();
        passwordField.setPromptText("Enter Password");
        passwordField.setMaxWidth(250);
        
        // Label to display error messages
        Label errorLabel = new Label();
        errorLabel.setStyle("-fx-text-fill: red; -fx-font-size: 12px;");


        Button loginButton = new Button("Login");
        
        loginButton.setOnAction(a -> {
        	// Retrieve user inputs
            String userName = userNameField.getText();
            String password = passwordField.getText();
            String email = databaseHelper.getUserEmail(userName);
            
            try {
            	User user=new User(userName, password, "", email);
            	WelcomeLoginPage welcomeLoginPage = new WelcomeLoginPage(databaseHelper);
            	
            	// Cheks if the user is logging in with a one time password
            	if (databaseHelper.isOneTimePassword(userName, password)) {
            		System.out.println("One-time password entered. Redirecting to password reset page...-->");
            		new ResetPasswordPage(databaseHelper, userName).show(primaryStage);
            	}
            	
            	// Retrieve the user's role from the database using userName
            	String role = databaseHelper.getUserRole(userName);
            	
            	if(role!=null) {
            		user.setRole(role);
            		if(databaseHelper.login(user)) {
            			if (role.length() == 4){
            	    		if(role.contains("adm")) {
            		    		new AdminHomePage(databaseHelper).show(primaryStage);
            		    	}
            		    	else if(role.contains("stu")) {
            		    		new StudentHomePage(databaseHelper).show(primaryStage, user);
            		    	}
            		    	else if(role.contains("rev")) {
            		    		new ReviewerHomePage(databaseHelper).show(primaryStage);
            		    	}
            		    	else if(role.contains("ins")) {
            		    		new InstructorHomePage(databaseHelper).show(primaryStage);
            		    	}
            		    	else if(role.contains("sta")) {
            		    		new StaffHomePage(databaseHelper).show(primaryStage);
            		    	}
            	    	}
            			else {
            			welcomeLoginPage.show(primaryStage,user);
            			}
            		}
            		else {
            			// Display an error if the login fails
                        errorLabel.setText("Error logging in");
            		}
            	}
            	else {
            		// Display an error if the account does not exist
                    errorLabel.setText("user account doesn't exists");
            	}
            	
            } catch (SQLException e) {
                System.err.println("Database error: " + e.getMessage());
                e.printStackTrace();
            } 
        });

        VBox layout = new VBox(10);
        layout.setStyle("-fx-padding: 20; -fx-alignment: center;");
        layout.getChildren().addAll(userNameField, passwordField, loginButton, errorLabel);

        primaryStage.setScene(new Scene(layout, 800, 400));
        primaryStage.setTitle("User Login");
        primaryStage.show();
    }
}
